import 'server-only';

import crypto from 'node:crypto';
import type { SupabaseClient, User } from '@supabase/supabase-js';
import { deleteExportJobFiles } from '@/lib/story/exportStore';
import { normalizedArtifactPathsFromManifest } from '@/lib/datasetArtifacts';
import { AccountApiError } from './server';
import { getStripeClient } from '@/lib/billing/stripeServer';

interface DeletionResourceSet {
  datasets?: Array<{
    id?: string;
    table?: string | null;
    file_url?: string | null;
    normalized_file_url?: string | null;
    analytics_manifest_url?: string | null;
  }>;
  export_job_ids?: string[];
  storage_paths?: string[];
  [key: string]: unknown;
}

function storagePath(url?: string | null) {
  if (!url) return null;
  const marker = '/storage/v1/object/public/files/';
  const index = url.indexOf(marker);
  return index >= 0 ? decodeURIComponent(url.slice(index + marker.length)) : null;
}

export function deletionTokenHash(token: string) {
  return crypto.createHash('sha256').update(token).digest('hex');
}

function tokenMatches(token: string, expectedHash: string) {
  const actual = Buffer.from(deletionTokenHash(token));
  const expected = Buffer.from(expectedHash);
  return actual.length === expected.length && crypto.timingSafeEqual(actual, expected);
}

export async function verifyRecentAuthentication(accessToken: string, user: User, nonce: string) {
  if (!/^\d{6}$/.test(nonce)) throw new AccountApiError(400, 'REAUTH_CODE_REQUIRED', 'Ingresa el código de autenticación reciente.');
  const response = await fetch(`${process.env.NEXT_PUBLIC_SUPABASE_URL}/auth/v1/user`, {
    method: 'PUT',
    headers: {
      apikey: process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || '',
      authorization: `Bearer ${accessToken}`,
      'content-type': 'application/json'
    },
    body: JSON.stringify({ data: user.user_metadata || {}, nonce }),
    cache: 'no-store'
  });
  if (!response.ok) throw new AccountApiError(401, 'RECENT_AUTHENTICATION_REQUIRED', 'El código expiró o no es válido. Solicita uno nuevo.');
}

async function completeStorageInventory(admin: SupabaseClient, userId: string, resources: DeletionResourceSet) {
  const paths = new Set<string>();
  const addOwnedPath = (path: string | null) => {
    if (!path) return;
    if (!path.startsWith(`${userId}/`)) throw new Error(`STORAGE_PATH_OWNERSHIP_MISMATCH ${path}`);
    paths.add(path);
  };
  (resources.storage_paths || []).forEach(addOwnedPath);
  for (const dataset of resources.datasets || []) {
    [dataset.file_url, dataset.normalized_file_url, dataset.analytics_manifest_url]
      .map(storagePath).forEach(addOwnedPath);
    const manifestPath = storagePath(dataset.analytics_manifest_url);
    if (manifestPath) {
      const { data, error } = await admin.storage.from('files').download(manifestPath);
      if (error || !data) throw new Error(`STORAGE_MANIFEST_READ_FAILED ${error?.message || manifestPath}`);
      let manifest: unknown;
      try { manifest = JSON.parse(await data.text()); }
      catch { throw new Error(`STORAGE_MANIFEST_INVALID ${manifestPath}`); }
      normalizedArtifactPathsFromManifest(manifest).forEach(addOwnedPath);
    }
  }
  return { ...resources, storage_paths: Array.from(paths) };
}

async function removeStorage(admin: SupabaseClient, paths: string[]) {
  for (let index = 0; index < paths.length; index += 100) {
    const { error } = await admin.storage.from('files').remove(paths.slice(index, index + 100));
    if (error) throw new Error(`STORAGE_CLEANUP_FAILED ${error.message}`);
  }
}

export async function processAccountDeletion(
  admin: SupabaseClient,
  requestId: string,
  userId: string,
  retryToken: string
) {
  const { data: request, error } = await admin.from('account_deletion_requests')
    .select('*').eq('id', requestId).eq('user_id', userId).single();
  if (error || !request || !tokenMatches(retryToken, request.retry_token_hash)) {
    throw new AccountApiError(403, 'INVALID_DELETION_RETRY', 'La solicitud de eliminación no es válida.');
  }
  if (request.status === 'completed') return;

  let stage = 'inventory';
  try {
    const resources = await completeStorageInventory(admin, userId, request.resources as DeletionResourceSet);
    await admin.from('account_deletion_requests').update({ resources, status: 'processing', updated_at: new Date().toISOString() }).eq('id', requestId);

    stage = 'validation';
    const { error: validationError } = await admin.rpc('assert_account_dataset_tables', { p_user_id: userId });
    if (validationError) throw validationError;

    stage = 'billing_preflight';
    const { data: billing } = await admin.from('account_subscriptions').select('stripe_subscription_id').eq('user_id', userId).maybeSingle();
    if (billing?.stripe_subscription_id && !process.env.STRIPE_SECRET_KEY?.startsWith('sk_test_')) {
      throw new Error('STRIPE_TEST_MODE_NOT_CONFIGURED');
    }

    stage = 'database';
    if (!request.database_cleaned_at) {
      const { error: cleanupError } = await admin.rpc('delete_account_product_data', { p_user_id: userId, p_request_id: requestId });
      if (cleanupError) throw cleanupError;
    }

    stage = 'storage';
    if (!request.storage_cleaned_at) {
      await removeStorage(admin, resources.storage_paths || []);
      await Promise.all((resources.export_job_ids || []).map((jobId) => deleteExportJobFiles(jobId)));
      await admin.from('account_deletion_requests').update({ storage_cleaned_at: new Date().toISOString(), updated_at: new Date().toISOString() }).eq('id', requestId);
    }

    stage = 'billing';
    if (billing?.stripe_subscription_id) {
      const subscription = await getStripeClient().subscriptions.retrieve(billing.stripe_subscription_id);
      if (!['canceled', 'incomplete_expired'].includes(subscription.status)) {
        await getStripeClient().subscriptions.cancel(subscription.id);
      }
    }

    stage = 'auth';
    const { error: authError } = await admin.auth.admin.deleteUser(userId);
    if (authError && !authError.message.toLowerCase().includes('not found')) throw authError;

    await admin.from('account_deletion_requests').update({
      status: 'completed', auth_deleted_at: new Date().toISOString(), completed_at: new Date().toISOString(),
      last_error: null, last_error_stage: null, updated_at: new Date().toISOString()
    }).eq('id', requestId);
  } catch (error) {
    const message = error instanceof Error ? error.message.slice(0, 1000) : 'ACCOUNT_DELETION_FAILED';
    await admin.from('account_deletion_requests').update({ status: 'failed', last_error: message, last_error_stage: stage, updated_at: new Date().toISOString() }).eq('id', requestId);
    throw new AccountApiError(500, 'ACCOUNT_DELETION_INCOMPLETE', 'La eliminación no terminó. Puedes reintentar de forma segura.', { requestId, stage });
  }
}
