# Sphere V1 Security Review

Generated: 2026-11-10

This archive contains the repository files still needed for an external security review of report and dataset permissions, public report publication, anonymous snapshot access, Supabase Storage access, and dependency/database auditing.

## Safety

- No environment files, credentials, private keys, tokens, user data, datasets, original uploads, Storage objects, or `node_modules` are included.
- No database, migration, Storage, or application operation was executed while preparing this archive.
- `npm audit --json` was executed without `npm audit fix`; its complete output is included at `security/npm-audit.json`.
- The owner UUID embedded in `20261103_roles_limits_dataset_protection.sql` was replaced only in this review copy with a non-functional all-zero placeholder. The repository source was not modified.

## Already Shared And Intentionally Omitted

- `SPHERE_V1_PRODUCTION_READINESS_2026-11-10.md`
- `sphere_v1_zero_reset_proposal.sql`
- `src/lib/story/persistence.ts`
- `package.json`
- `package-lock.json`

## Migration Inventory

- `supabase/migrations/20260407_analytics_provider.sql`: dataset access policies, grants, analytics table synchronization, and dataset query execution.
- `supabase/migrations/20260412_fix_sync_normalized_dataset_alias.sql`: normalized dataset synchronization function correction.
- `supabase/migrations/20260727_m1_instant_wow.sql`: public report snapshots, owner policies, and anonymous active-snapshot access.
- `supabase/migrations/20260728_m2_story_persistence.sql`: Story persistence, public Story snapshots, export jobs, and public access policies.
- `supabase/migrations/20260729_m25_snapshot_owner_select.sql`: owner visibility for public report snapshots.
- `supabase/migrations/20260903_sphere_lifecycle_stabilization.sql`: report/dataset lifecycle functions, snapshot lifecycle, ownership, and cleanup behavior.
- `supabase/migrations/20261103_roles_limits_dataset_protection.sql`: role-based dataset/report limits and protected dataset deletion. The configured owner UUID is redacted in this archive.
- `supabase/migrations/20261105_large_dataset_chunked_sync.sql`: chunked normalized-dataset synchronization and staging-session controls.
- `supabase/migrations/20261106_large_dataset_finalize_timeout.sql`: large-dataset finalization changes.
- `supabase/migrations/20261107_optimize_large_dataset_finalize.sql`: large-dataset finalization performance and integrity changes.
- `supabase/migrations/20261108_harden_dataset_query_execution.sql`: hardened dataset query RPC.
- `supabase/migrations/20261109_superadmin_administration.sql`: administrative roles, account state, audit support, and `storage.objects` access restrictions.
- `supabase/migrations/20261110_account_self_service.sql`: account lifecycle, subscriptions, deletion, and related security policies.

## Publication, Snapshot, And Storage Code

- `src/lib/publishing.ts`: private report materialization and report snapshot publish/republish/revoke lifecycle.
- `src/lib/story/publishing.ts`: Story materialization and public Story snapshot lifecycle.
- `src/app/report/[id]/page.tsx`: anonymous public report snapshot lookup and rendering.
- `src/app/story/[slug]/page.tsx`: anonymous public Story snapshot lookup and rendering.
- `src/lib/supabase.ts`: browser Supabase client construction.
- `src/lib/supabaseServer.ts`: server Supabase client construction and session propagation.
- `src/lib/admin/server.ts`: privileged server-only Supabase administrative client and authorization checks.
- `src/lib/account/deletionServer.ts`: account deletion orchestration and Storage cleanup.
- `src/lib/datasetArtifacts.ts`: dataset artifact URL/path generation and Storage upload/download behavior.
- `src/app/api/lifecycle/dataset-artifacts/[datasetId]/route.ts`: authenticated dataset artifact cleanup endpoint.
- `src/app/api/lifecycle/story-artifacts/[storyId]/route.ts`: authenticated Story artifact cleanup endpoint.
- `src/components/quick-result/QuickResultView.tsx`: report publication/export UI integration and public URL consumption.
- `src/components/canvas/ReportCanvas.tsx`: private report loading, save, publication, and public URL integration.

## Audit Artifacts

- `security/npm-audit.json`: complete dependency audit output from `npm audit --json`.
- `tests/sql/supabase_readonly_audit.sql`: read-only Supabase schema, policy, function, Storage, integrity, and orphan-candidate audit.

## Repository Coverage Gaps

The current migration history does not contain the original `CREATE TABLE`/RLS migration for `public.reports`, nor the original creation/configuration of the `files` Storage bucket. Later migrations modify or depend on those objects, but cannot prove their complete initial configuration. The external review should therefore compare the live schema and bucket settings with the read-only audit output.

## Manual Supabase Audit

1. Open the development Supabase project in **SQL Editor** using an authorized role that can inspect `pg_catalog`, `public`, `storage`, and, when installed, `cron`.
2. Open `tests/sql/supabase_readonly_audit.sql`, verify the target project, and run it unchanged. Every statement is read-only.
3. Export each result grid in execution order as CSV (or JSON where preferred) using these names:

   - `01_migration_history.csv`
   - `02_relations.csv`
   - `03_columns.csv`
   - `04_constraints.csv`
   - `05_indexes.csv`
   - `06_duplicate_indexes.csv`
   - `07_unindexed_foreign_keys.csv`
   - `08_triggers.csv`
   - `09_rls_policies.csv`
   - `10_tables_without_rls.csv`
   - `11_functions.csv`
   - `12_table_grants.csv`
   - `13_extensions.csv`
   - `14_dynamic_tables.csv`
   - `15_sync_sessions.csv`
   - `16_unreferenced_staging_tables.csv`
   - `17_unreferenced_dataset_tables.csv`
   - `18_integrity_issues.csv`
   - `19_publication_export_issues.csv`
   - `20_dataset_metadata_issues.csv`
   - `21_storage_inventory.csv`
   - `22_missing_storage_objects.csv`

4. If result 13 shows `pg_cron`, run this separate read-only query and export it as `13b_cron_jobs.csv`:

   ```sql
   select jobid, jobname, schedule, command, active
   from cron.job;
   ```

5. Review exports before external sharing. Results 15 and 20 can contain dataset identifiers, names, or artifact URLs; results 21 and 22 can contain Storage object names. Redact personal/customer data and signed URL parameters, or transfer unredacted evidence only through the approved secure channel.
6. Do not run cleanup scripts, `DROP`, `TRUNCATE`, `DELETE`, schema changes, or migration commands as part of this audit.
